"""Sensor fault check for the Gaussian field model: predict each sensor from the others and drop one that disagrees.

    loo_z(gf, S, y, noise)            -> (B, m) z of each reading against its prediction from the other m - 1 sensors
    threshold(alpha, m)               -> two-sided Bonferroni z for m sensors: under the model a healthy case exceeds
                                         it on any sensor with probability at most alpha
    repair(gf, S, y, noise, z_max)    -> (field means (B, n), dropped sensor per case or -1)
    offsets(gf, S, y_cal, noise)      -> (m,) each sensor's fixed offset (K), estimated from calibration cases without
                                         true temperatures; subtract it from later readings. A fault already present
                                         during calibration is folded into its offset.

Offsets: the leave-one-out prediction is linear in the readings, pred_i = a_i + sum_j W_ij y_j, so offsets o shift
each sensor's mean residual by ((I - W) o)_i: one sensor's offset also shows in the residuals of the sensors it helps
predict. offsets() solves (I - W) o = mean residual by least squares, dropping singular values below 1% of the
largest: an offset pattern the field model could explain as heat is not identifiable, and is left at zero (the check
cannot see it either). One pass without the solve leaked a 30-sigma offset into its neighbours at up to 0.4 of its
size, enough to raise false alarms by itself (tests/test_fault.py).
"""
import numpy as np
from scipy.stats import norm


def loo_z(gf, S, y, noise):
    S = np.asarray(S)
    y = np.atleast_2d(np.asarray(y, dtype=np.float64))
    z = np.empty_like(y)
    for i in range(len(S)):
        keep = np.arange(len(S)) != i
        post = gf.posterior(S[keep], y[:, keep], noise)
        z[:, i] = (y[:, i] - post.mean[:, S[i]]) / np.sqrt(post.std[S[i]] ** 2 + noise ** 2)
    return z


def threshold(alpha, m):
    if not 0 < alpha < 1 or m < 1:
        raise ValueError("need 0 < alpha < 1 and m >= 1")
    return float(norm.ppf(1 - alpha / (2 * m)))


def repair(gf, S, y, noise, z_max):
    S = np.asarray(S)
    y = np.atleast_2d(np.asarray(y, dtype=np.float64))
    if len(S) < 2:
        raise ValueError("a fault check needs at least two sensors")
    z = np.abs(loo_z(gf, S, y, noise))
    worst = z.argmax(1)
    dropped = np.where(z[np.arange(len(y)), worst] > z_max, worst, -1)
    mean = gf.posterior(S, y, noise).mean
    for i in np.unique(dropped[dropped >= 0]):
        rows = dropped == i
        keep = np.arange(len(S)) != i
        mean[rows] = gf.posterior(S[keep], y[rows][:, keep], noise).mean
    return mean, dropped


def loo_weights(gf, S, noise):
    """W (m, m): the leave-one-out prediction of sensor i is a_i + W[i] @ y (W[i, i] = 0)."""
    S = np.asarray(S)
    m = len(S)
    W = np.zeros((m, m))
    basis = np.vstack([np.zeros(m - 1), np.eye(m - 1)])
    for i in range(m):
        keep = np.arange(m) != i
        mu = gf.posterior(S[keep], basis, noise).mean[:, S[i]]
        W[i, keep] = mu[1:] - mu[0]
    return W


def offsets(gf, S, y_cal, noise, rcond=0.01):
    S = np.asarray(S)
    y_cal = np.atleast_2d(np.asarray(y_cal, dtype=np.float64))
    resid = np.empty(len(S))
    for i in range(len(S)):
        keep = np.arange(len(S)) != i
        resid[i] = float(np.mean(y_cal[:, i] - gf.posterior(S[keep], y_cal[:, keep], noise).mean[:, S[i]]))
    return np.linalg.lstsq(np.eye(len(S)) - loo_weights(gf, S, noise), resid, rcond=rcond)[0]
